Ryan Coslove rmc326

My testing strategy was to use the correct example inputs in the project pdf.
Then I tried using messages I knew would result in errors so I could see if
the server would close. I tried doing manual closing and automatic. I tried
getting different key codes. 
